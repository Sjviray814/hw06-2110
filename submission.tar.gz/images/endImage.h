/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 endImage endImage.png 
 * Time-stamp: Thursday 04/03/2025, 20:59:47
 * 
 * Image Information
 * -----------------
 * endImage.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ENDIMAGE_H
#define ENDIMAGE_H

extern const unsigned short endImage[38400];
#define ENDIMAGE_SIZE 76800
#define ENDIMAGE_LENGTH 38400
#define ENDIMAGE_WIDTH 240
#define ENDIMAGE_HEIGHT 160

#endif

