/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=30x30 hi_score images/hi_score.png 
 * Time-stamp: Friday 04/04/2025, 20:28:58
 * 
 * Image Information
 * -----------------
 * images/hi_score.png 30@30
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef HI_SCORE_H
#define HI_SCORE_H

extern const unsigned short hi_score[900];
#define HI_SCORE_SIZE 1800
#define HI_SCORE_LENGTH 900
#define HI_SCORE_WIDTH 30
#define HI_SCORE_HEIGHT 30

#endif

