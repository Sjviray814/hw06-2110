/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 images/CoverImage images/CoverImage.png 
 * Time-stamp: Thursday 04/03/2025, 21:57:37
 * 
 * Image Information
 * -----------------
 * images/CoverImage.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef COVERIMAGE_H
#define COVERIMAGE_H

extern const unsigned short CoverImage[38400];
#define COVERIMAGE_SIZE 76800
#define COVERIMAGE_LENGTH 38400
#define COVERIMAGE_WIDTH 240
#define COVERIMAGE_HEIGHT 160

#endif

