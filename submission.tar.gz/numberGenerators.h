#ifndef NUMBERGENERATORS_H
#define NUMBERGENERATORS_H


int generateTwoDigitNumber(int exclude);
int generateFourDigitNumber(int exclude);
long generateEightDigitNumber(int exclude);


#endif