This game is called block eater and is a game where you have to eat blocks based on certain random clues generated.
A more detailed explanation of how to understand clues and play the game is under "How to play" in the home menu.

Controls:
- Arrow keys for movement, up and down for movement in home screen
- Enter to select an option on title screen, or to return to title screen from lose screen or "how to play" screen
- Backspace to fully reset the program including saved high score